from datetime import date
import pandas as pd
import quandl
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
import numpy as np
from tensorflow.keras import layers, Sequential
import tensorflow as tf

gpus = tf.config.experimental.list_physical_devices('GPU')
print(gpus)
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)
    
start = date(2000,10,12)
end = date.today()
google_stock = pd.read_csv("./LBMA-GOLD.csv").dropna(axis=0)

def run(time_stamp = 30):
    global google_stock
    google_stock = google_stock[['Value']]

    train = google_stock[0:900 + time_stamp]
    valid = google_stock[900 + time_stamp:]

    scaler = MinMaxScaler(feature_range=(0, 1))  
    scaled_data = scaler.fit_transform(train)
    x_train, y_train = [], []

    for i in range(time_stamp, len(train)):
        x_train.append(scaled_data[i - time_stamp:i])
        y_train.append(scaled_data[i, 0])

    x_train, y_train = np.array(x_train), np.array(y_train)

    scaled_data = scaler.fit_transform(valid)
    x_valid, y_valid = [], []
    for i in range(time_stamp, len(valid)):
        x_valid.append(scaled_data[i - time_stamp:i])
        y_valid.append(scaled_data[i, 0])

    x_valid, y_valid = np.array(x_valid), np.array(y_valid)

    scaled_data = scaler.fit_transform(google_stock)
    x_total, y_total = [], []
    for i in range(time_stamp, len(google_stock)):
        x_total.append(scaled_data[i - time_stamp:i])
        y_total.append(scaled_data[i, 0])

    x_total, y_total = np.array(x_total), np.array(y_total)

    epochs = 30
    batch_size = 16
    model = Sequential()
    model.add(layers.LSTM(units=100, return_sequences=True,
              input_dim=x_train.shape[-1], input_length=x_train.shape[1]))
    model.add(layers.LSTM(units=50))
    model.add(layers.Dense(1))
    model.compile(loss='mean_squared_error', optimizer='adam')
    model.fit(x_train, y_train, epochs=epochs, batch_size=batch_size, verbose=1)


    x_valid_predict = model.predict(x_valid)
    scaler.fit_transform(pd.DataFrame(valid['Value'].values))
    x_valid_predict = scaler.inverse_transform(x_valid_predict)
    y_valid = scaler.inverse_transform([y_valid])

    rms = np.sqrt(np.mean(np.power((y_valid - x_valid_predict), 2)))
    print(f"test_rms:{rms}")
    return rms
run()