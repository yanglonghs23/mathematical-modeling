from datetime import date
import pandas as pd
import quandl
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
import numpy as np
from tensorflow.keras import layers, Sequential, models
import tensorflow as tf
import pickle

df = pd.read_csv("./input.csv")
xt = list(df["usd"])
xt_1 = list(df["usd_nextday_predict"])
yt = list(df["Value"])
yt_1 = list(df["BCHAIN-MKPRU_nextday_predict"])
beta_b = 95  # 1-100
beta_c = 28  # 1-100

for i in range(len(xt) - 1):
    if xt[i + 1] == 0:
        xt[i + 1] = xt[i]
        if xt_1[i + 1] == 0:
            xt_1[i + 1] = xt[i + 1]

def run(erfa_b = 2,erfa_c = 1):
    result = [1000,0,0] # crash gold bitcion
    for i in range(len(xt)-1):
        if xt[i+1]==xt_1[i+1] and 
           yt_1[i+1]>(1+beta_b*0.01)*yt[i+1]:
            result[2]=result[2]*(1+(yt[i+1]-yt[i])/yt[i])+\
                         result[0]*(1-erfa_b*0.01)
            result[0]=0
        elif xt[i+1]==xt_1[i+1] and 
             yt_1[i+1] < yt[i+1]*(1-beta_b*0.01):
            result[0]=result[0]+result[2]*
                      (1+(yt[i+1]-yt[i])/yt[i])*(1-erfa_b*0.01)
            result[2]=0
        elif xt[i+1]*(1-beta_c*0.01)<=xt_1[i+1]<=(1+beta_c*0.01)*xt[i+1] and
             yt[i+1]*(1-beta_b*0.01)<=yt_1[i+1]<=(1+beta_b*0.01)*yt[i+1]:
            result[1]=result[1]*(1+(xt[i+1]-xt[i])/xt[i])
            result[2]=result[2]*(1+(yt[i+1]-yt[i])/yt[i])

        elif xt_1[i+1]>(1+beta_c*0.01)*xt[i+1] and 
            (xt_1[i+1]-xt[i+1])*yt[i+1]>=(yt_1[i+1]-yt[i+1])*xt[i+1]:
            result[1]=result[1]*(1+(xt[i+1]-xt[i])/xt[i]) + \
                      result[2]*(1+(yt[i+1]-yt[i])/yt[i])*
                      (1-erfa_b*0.01-erfa_c*0.01) +\
                      result[0]*(1-erfa_c*0.01)
            result[0] = 0
            result[2] = 0
        elif yt_1[i+1] > (1+beta_b*0.01)*yt[i+1] and 
             (yt_1[i+1]-yt[i+1])*xt[i+1] >= (xt_1[i+1]-xt[i+1])*yt[i+1]:
            result[2] = result[2]*(1+(yt[i+1]-yt[i])/yt[i]) + \
                        result[0]*(1-erfa_b*0.01) + \
                        result[1]*(1+(xt[i+1]-xt[i])/xt[i])*
                        (1-erfa_b*0.01-erfa_c*0.01)
            result[0] = 0
            result[1] = 0
        elif xt_1[i+1] < xt[i+1]*(1-beta_c*0.01) and
             yt_1[i+1] < yt[i+1]*(1-beta_b*0.01):
            result[0] = result[0] + \
                        result[1]*(1+(xt[i+1]-xt[i])/xt[i])*(1-erfa_b*0.01)+\
                        result[2]*(1+(yt[i+1]-yt[i])/yt[i])*(1-erfa_c*0.01)
            result[1] = 0
            result[2] = 0

    return result

def main():
    temp = [(95, 28),(49, 11),(13, 93),(17, 5)]
    for k in range(4):
        global beta_b
        global beta_c
        beta_b, beta_c = temp[k]
        data = dict()
        for i in np.arange(1,11,0.1):
            for j in np.arange(1,11,0.1):
                data[str((i, j))] = sum(run(i,j))
                print(data[str((i, j))])
        with open(f"result{k}.pkl","wb") as f:
            pickle.dump(data,f)


if __name__ == '__main__':
    main()